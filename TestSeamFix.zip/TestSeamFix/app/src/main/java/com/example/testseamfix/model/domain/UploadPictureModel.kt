package com.example.testseamfix.model.domain

class UploadPictureModel(val status: String)